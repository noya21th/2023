switch(window.location.hostname){

case "wind.vnet.cn":
case "vnet.wind.yinsha.com":
case "vnet.wind.silversand.net":
case "wind.gd.chinavnet.com":
src="http://gd.chinavnet.com/index_head.jsp";
width=760;
height=100;
break;

default:
src="http://vnetscript.silversand.net/wind/yinsha.htm";
width=760;
height=110;
}

document.write("<iframe src=\'"+src+"\' width="+width+" height="+height+" align=center noresize frameborder=0 border=0 bordercolor=000000 hspace=0 vspace=0 marginwidth=0 marginheight=0 scrolling=no></iframe>");